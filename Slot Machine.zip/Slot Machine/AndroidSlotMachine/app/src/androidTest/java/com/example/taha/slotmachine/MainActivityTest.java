package com.example.taha.slotmachine;

import static org.junit.Assert.*;

/**
 * Created by spawn on 2018-03-02.
 */
public class MainActivityTest {

}